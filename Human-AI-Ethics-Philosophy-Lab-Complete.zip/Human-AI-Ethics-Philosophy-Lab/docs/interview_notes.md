# Interview Notes

### 30-second explanation
I built a Human-AI Ethics and Philosophy Lab using 1,000 synthetic AI decision cases. I analyzed fairness, privacy, autonomy, accountability, explainability, human benefit, and harm risk, then built responsible-AI and human-AI alignment indices and applied statistics and clustering.

### Main caveat
The scores are analytical abstractions and are not objective measurements of morality.
