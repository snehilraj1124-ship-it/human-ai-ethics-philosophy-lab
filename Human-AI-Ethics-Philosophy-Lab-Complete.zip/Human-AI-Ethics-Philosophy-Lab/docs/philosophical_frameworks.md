# Philosophical Frameworks

## Deontology
Focuses on duties, rights, rules, and constraints.

## Utilitarianism
Evaluates outcomes through benefits and harms.

## Virtue Ethics
Considers responsible action and character.

## Justice Ethics
Focuses on fairness, equality, and distribution.

## Human Agency
Emphasizes meaningful human control over consequential decisions.
