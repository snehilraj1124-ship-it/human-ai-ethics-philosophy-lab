# Limitations

- Synthetic data
- Simplified ethical dimensions
- Manually chosen weights
- No causal inference
- Exploratory clusters
- No claim of objective moral measurement
