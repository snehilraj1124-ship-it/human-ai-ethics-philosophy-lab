# Methodology

The project generates 1,000 synthetic AI decision cases, validates the variables, constructs analytical indices, performs statistical analysis, and applies exploratory machine learning.

The framework is intended for portfolio and educational use rather than real-world automated governance.
