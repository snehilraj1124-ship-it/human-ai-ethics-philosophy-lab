# Ethics & Responsible Use

All observations are synthetic. Do not use these indices to make real-world high-stakes decisions or to automate moral judgments. Human oversight and domain expertise remain essential.
