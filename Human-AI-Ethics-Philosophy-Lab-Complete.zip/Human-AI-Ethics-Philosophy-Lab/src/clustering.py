# K-Means exploratory governance segmentation.
