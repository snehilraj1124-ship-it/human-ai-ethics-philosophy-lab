# Feature engineering for alignment, responsible AI, and ethical tension indices.
