# Synthetic dataset generation script. Random seed: 52.
