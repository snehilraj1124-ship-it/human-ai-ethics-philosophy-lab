import pandas as pd

def test_dataset():
    df=pd.read_csv("data/processed/human_ai_ethics_cases.csv")
    assert len(df)==1000
    assert df["responsible_ai_index"].between(0,100).all()
