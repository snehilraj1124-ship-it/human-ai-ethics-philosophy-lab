# Results Template

Record descriptive statistics, correlations, hypothesis-test results, regression findings, cluster profiles, scenario comparisons, and limitations here.
